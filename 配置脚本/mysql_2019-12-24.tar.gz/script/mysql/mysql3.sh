#!/bin/bash
db_ps=`/usr/bin/ps -ef|grep mysqld|wc -l`
port=`/usr/sbin/ss -luntp|grep 3306|wc -l`
if [ $db_ps -ne 2 ] && [ $port -ne 1 ];then

	`/usr/bin/systemctl start mysqld`
	echo "mysql_server login succeed"
else
	echo "mysql runing"
fi
