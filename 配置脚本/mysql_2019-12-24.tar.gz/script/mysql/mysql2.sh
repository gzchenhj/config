#!/bin/bash
port=`/usr/bin/ps -ef|grep mysqld|wc -l`

if [ $port -ne 2 ];then

	`/usr/bin/systemctl start mysqld`
	echo "mysql_server login succeed"
else
	echo "mysql runing"
fi
