#!/bin/bash
/usr/local/mysql/bin/mysql -uroot -p123456 -e "select version();" >/dev/null 2>&1
if [ $? -ne 0 ] ;then

	/usr/bin/systemctl start mysqld
	echo "mysql_server login succeed"
else
	echo "mysql runing"
fi
