#!/bin/bash
port=`/usr/sbin/ss -luntp|grep 3306|awk -F "[: ]+" '{print $5}'`

if [ "$port"!="3306" ];then

	`/usr/bin/systemctl start mysqld`
	echo "mysql_server login succeed"
fi
