#!/bin/bash
#name chenhaijun
#date 2019-12-26
#by start http nginx
#version 1.0

. /etc/init.d/functions

if [ $# -ne 1 ]
 then
	echo "uesig{start|stop|restart}"
	exit 1
fi

if [ "$1" == "start" ]
 then 
	action "starting nginx"     /usr/bin/true
elif [ "$1" == "stop" ]
 then
	action "starting nginx"     /bin/true
elif [ "$1" == "restart" ]
 then
	 action "starting nginx"     /bin/true
fi


