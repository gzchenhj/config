#!/bin/bash
#name chenhaijun
#date 2019-12-26
#by start http nginx
#version 1.0

. /etc/init.d/functions
 start_nginx=/usr/local/nginx/sbin/nginx
USAGE() {
	echo "USAGE $0 {start|stop|restart}"
	exit 1
}
if [ $# -ne 1 ]
 then
	USAGE
fi

if [ "$1" == "start" ]
 then 
	$start_nginx
	action "starting nginx"     /usr/bin/true
	exit 0
else
	action "starting nginx"     /usr/bin/false
	exit 1
fi
if [ "$1" == "stop" ]
 then
	pkill nginx
	action "stoping nginx"     /bin/true
	exit 0
else
	action "stoping nginx"     /bin/false
	exit 1
fi
if [ "$1" == "restart" ]
 then
	pkill nginx
	sleep 3
	$start_nginx
	action "restarting nginx"     /bin/true
	exit 0
else
	action "restarting nginx"     /bin/false
	exit 1
fi
